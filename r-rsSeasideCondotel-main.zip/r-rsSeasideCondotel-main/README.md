# r-rsSeasideCondotel

July 03, 2023
- Add Fb page link in the contact section
- rephrase the contact page header with "Booking and inquiries"
- Remove "contact us" from the contact page
- Switch the FB link and phone number from the footer section
- add "...will respond within 24 hours-contact page" in the contact sections sub-header
- Add house rules section
- Add check-in and check-out dates in the contact section
- Add guest counter in the contact section
- Advert sticker for FB page on the bottom right of the screen
- Disable auto slide when the user interacts with the slider in the TESTIMONIALS section

July 04, 2023
- Updated About content in the footer section
- Updated height responsiveness for the facilities, about, find us, and contact sections
- add a new testimonial by Wondermom
- readjusted code for the testimonial section

July 05, 2023
- Updated Navigation UX
- Updated Stikky advert sticker to disappear when fb link is part of the section content
- 

To Do:
Update rules section
Add keep the apartment clean
